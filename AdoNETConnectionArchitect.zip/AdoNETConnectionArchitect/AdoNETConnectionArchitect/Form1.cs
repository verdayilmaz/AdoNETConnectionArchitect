﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNETConnectionArchitect
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnManual_Click(object sender, EventArgs e)
        {
            string baglanti = "server=.;uid=sa;password=123456789?;database = Northwind;pooling = true";

            SqlConnection cnn = new SqlConnection(baglanti);
            cnn.Open();
            MessageBox.Show("Baglantı Acildi");
            //veri cekme işlemlerimizi burada gercekleştiriyoruz
            cnn.Close();
            MessageBox.Show("Baglantı kapatıldı");

        }

        private void btnBuilder_Click(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder csb = new SqlConnectionStringBuilder();
            csb.UserID = "sa";
            csb.DataSource = ".";
            csb.Password = "123456789?";
            csb.InitialCatalog = "Northwind";
            csb.Pooling = true;
            csb.MaxPoolSize = 5;
            SqlConnection cnn = new SqlConnection(csb.ConnectionString);

            if (cnn.State == ConnectionState.Closed)
            {
                cnn.Open();
            }
            MessageBox.Show("Baglantı acildi");

            cnn.Close();
            MessageBox.Show("Baglantı kapatıldı");

        }

        private void btnProp_Click(object sender, EventArgs e)
        {
            SqlConnection cnn = new SqlConnection(Properties.Settings.Default.MyConnection);
            if (cnn.State == ConnectionState.Closed)
            {
                cnn.Open();
            }
            MessageBox.Show("baglantı basarılı");

            cnn.Close();
            MessageBox.Show("baglantı kapatıldı");
        }
    }
}
